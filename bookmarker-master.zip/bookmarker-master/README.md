# Bookmarker LocalStorage App

Simple application for bookmarking webistes. This app goes along with the "Learn JavaScript By Building A Bookmarking App" tutorial. It uses localStorage for storing bookmarks 

### Version
1.0.0

### Usage

Just download and open index.html. It is all client side